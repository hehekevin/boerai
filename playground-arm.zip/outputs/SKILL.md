---
name: literature-search-forge
description: 文献检索工具，支持多数据库检索、引文追踪、跨语言搜索
version: 1.0.0
tags: [literature-search, week4, challenge-0467f5db]
---

# literature-search-forge

## 功能概述

文献检索工具，支持多数据库检索、引文追踪、跨语言搜索

## 核心能力

- 检索策略、数据库选择、结果筛选、引文网络分析
- 智能分析与建议
- 结构化输出
- 可追溯的工作流程

## 输入要求

- 题目ID: challenge-0467f5db
- 题目: 检索覆盖率与遗漏分析
- 赛道: Literature Search

## 工作流程

1. **需求分析**: 理解题目要求和评分标准
2. **方案设计**: 设计解决方案和实施策略
3. **执行实施**: 按照方案逐步执行
4. **质量检查**: 验证输出质量和完整性
5. **结果交付**: 生成最终交付物

## 输出规范

- 结构化、可追溯
- 符合学术规范
- 包含必要的引用和来源
- 提供清晰的说明文档

## 使用示例

```bash
# 调用示例
python3 literature-search-forge.py --input data.json --output result.md
```

## 注意事项

- 确保输入数据的完整性
- 遵循学术诚信原则
- 保留所有中间步骤的记录
- 输出结果需要人工审核

## 版本历史

- v1.0.0: 初始版本，支持Literature Search赛道基础功能
